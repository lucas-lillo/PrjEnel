/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prjenel;

/**
 *
 * @author x542895
 */
public class PrjEnel {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
